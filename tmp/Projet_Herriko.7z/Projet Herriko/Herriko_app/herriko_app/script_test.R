library(dplyr)
library(shiny)
library(shinydashboard)
library(shinythemes)
library(ggplot2)
library(hrbrthemes)
library(tidyr)



sales2019 <- read.csv('herriko_app/ventes_2019.csv', sep = ';')
sales2019 <- sales2019 %>%  mutate(Commune = tolower(Commune))

prix2019 <- read.csv('herriko_app/prix_2019.csv', sep = ';')

communes <- read.csv('herriko_app/communes.csv', sep = ';')
communes <-  communes %>% mutate(Commune = tolower(Commune))

salebycom <- merge(sales2019, communes, by = 'Commune')

villes <- data.frame(Ville = salebycom$Commune,
                       Latitude = salebycom$latitude,
                       Longitude = salebycom$longitude)
                      
data_map <- villes %>% 
  group_by(Ville, Latitude, Longitude) %>% 
  summarise(nb_ville = n())
