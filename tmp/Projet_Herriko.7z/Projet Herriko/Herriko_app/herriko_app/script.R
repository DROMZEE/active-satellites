library(dplyr)
library(shiny)
library(shinydashboard)
library(shinythemes)
library(ggplot2)
library(hrbrthemes)


prix2019 <- read.csv('herriko_app/prix_2019.csv', sep = ';')

prix2019[,1]
names(prix2019[1])

sales <- read.csv('herriko_app/ventes_2019.csv', sep = ';')
names(sales)


sales