#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(shinyWidgets)
library(leaflet)
library(dplyr)
library(shiny)
library(shinydashboard)
library(shinythemes)
library(ggplot2)
library(hrbrthemes)
library(tidyr)

# Tables
sales2019 <- read.csv('ventes_2019.csv', sep = ';')
sales2019 <- sales2019 %>%  mutate(Commune = tolower(Commune))

prix2019 <- read.csv('prix_2019.csv', sep = ';')

communes <- read.csv('communes.csv', sep = ';')
communes <-  communes %>% mutate(Commune = tolower(Commune))

salebycom <- merge(sales2019, communes, by = 'Commune')

todayDate <- format(Sys.time(), "%a %d %b %Y")

r_colors <- rgb(t(col2rgb(colors()) / 255))
names(r_colors) <- colors()

# Define UI for application that draws a histogram
ui <- navbarPage(
  'Herriko Haragia',
  theme = shinytheme('cerulean'),
  
  tabPanel('Accueil',
           sidebarLayout(
             sidebarPanel(
               img(src = 'user_icon.png', width = 70, align = 'center'),
               h4('Benoit Jean'),
               h4(todayDate),
               tags$hr()
             ),
             mainPanel(
               h2('Tableau de Bord principal'),
               h4('Evolution des Prix'),
               plotOutput("pricePlot"),
               tableOutput("excel1")
             )
           )
  ),
  
  tabPanel('Analyse Données',
           sidebarLayout(
             sidebarPanel(
               img(src = 'user_icon.png', width = 70, align = 'center'),
               h4('Benoit Jean'),
               tags$hr()
               
             ),
             mainPanel(
               h2('Analyse de Données'),
               table('test')
               
             )
           )
  ),
  
  tabPanel('Carte Interactive',
           sidebarLayout(
             sidebarPanel(
               img(src = 'user_icon.png', width = 70, align = 'center'),
               h4('Benoit Jean'),
               tags$hr(),
               
               selectInput('sel_town',
                           'Commune :',
                           c('Tout',
                             unique(as.character(sales2019$Commune))))
               
             ),
             mainPanel(
               
               h2('Carte Interactive'),
               h4('Visualisation des points de ventes partenaires.'),
               leafletOutput("mymap"),
               p(),
               actionButton("recalc", "Nouveau point")
             )
           )
  ),
  
  tabPanel('Ventes Opérateurs',
           sidebarLayout(
             sidebarPanel(
               img(src = 'user_icon.png', width = 70, align = 'center'),
               h4('Benoit Jean'),
               tags$hr(),
               helpText('Filtrez les données en sélectionnant les critères qui vous intéressent.'),
               
               selectInput('sel_cust',
                           'Clients :',
                           c('Tout',
                             unique(as.character(sales2019$Clients)))),
               
               selectInput('sel_type',
                           'Type de clients :',
                           c('Tout',
                             unique(as.character(sales2019$Type.de.client)))),
               
               selectInput('sel_zone',
                           'Zone géographique :',
                           c('Tout',
                             unique(as.character(sales2019$Zone.géographique)))),
               
               selectInput('sel_city',
                           'Commune :',
                           c('Tout',
                             unique(as.character(sales2019$Commune)))),
               tags$hr()
               
             ),
             
             mainPanel(
               h2('Ventes Opérateurs'),
               DT::dataTableOutput('sales')
             )
           )
  ),
  
  ### Onglet FUSION TABLE
  tabPanel('Fusion de tableaux',
           sidebarLayout(
             
             # Sidebar panel for inputs ----
             sidebarPanel(
               img(src = 'user_icon.png', width = 70, align = 'center'),
               h4('Benoit Jean'),
               
               tags$hr(),
               
               # Input: Select a file ----
               fileInput("csv1", "Opérateur 1 : ",
                         buttonLabel = 'Importer un fichier',
                         multiple = TRUE,
                         accept = c("text/csv",
                                    "text/comma-separated-values,text/plain",
                                    ".csv")),
               
               fileInput("csv2", "Opérateur 2 : ",
                         buttonLabel = 'Importer un fichier',
                         multiple = FALSE,
                         accept = c(
                           "text/csv",
                           "text/comma-separated-values,text/plain",
                           ",",
                           ".csv")
               ),
               
               fileInput("csv3", "Opérateur 3 : ",
                         buttonLabel = 'Importer un fichier',
                         multiple = FALSE,
                         accept = c(
                           "text/csv",
                           "text/comma-separated-values,text/plain",
                           ",",
                           ".csv")
               ),
               
               fileInput("csv4", "Opérateur 4 : ",
                         buttonLabel = 'Importer un fichier',
                         multiple = FALSE,
                         accept = c(
                           "text/csv",
                           "text/comma-separated-values,text/plain",
                           ",",
                           ".csv")
               ),
               tags$hr(),
               
               actionButton("fusionBtn", "Fusionner les tableaux", class = "btn-primary"),
               
               tags$hr(),
               
               downloadButton('downloadBtn', "Télécharger sous Excel", class = "btn-success")
               
             ),
             
             # Main panel for displaying outputs ----
             mainPanel(
               
               h2('Fusion des données'),
               h4('Sélectionnez les tableaux des opérateurs à fusionner.'),
               textOutput("csvname1"),
               textOutput("csvname2"),
               textOutput("csvname3"),
               textOutput("csvname4"),
               textOutput("fus_ok"),
               DT::dataTableOutput('final')
               
             )
           )
  ),
  
  # Footer
  tags$footer("Herriko Harragia © - 
              Dashboard By Meidi KADRI - Cédric DROMZEE - Ronan PELE - 2020",
              align = "center", 
              style = "
              position:absolute;
              bottom:0;
              width:100%;
              height:50px;   /* Height of the footer */
              color: white;
              padding: 10px;
              background-color: #3A9AD1;
              z-index: 1000;")
  )


# Define server logic required to draw a histogram
server <- function(input, output, session) {
  
  output$test <- renderTable(salebycom)
  
  ########################################
  ##### Ventes
  
  output$sales <- DT::renderDataTable(DT::datatable({
    data <- salebycom
    if (input$sel_cust != 'Tout'){
      data <- data[data$Clients == input$sel_cust, ]
    }
    if (input$sel_type != 'Tout'){
      data <- data[data$Type.de.client == input$sel_type, ]
    }
    if (input$sel_zone != 'Tout'){
      data <- data[data$Zone.géographique == input$sel_zone, ]
    }
    if (input$sel_city != 'Tout'){
      data <- data[data$Commune == input$sel_city, ]
    }
    data
  }))
  
  # output$sales <- DT::renderDataTable(DT::datatable({
  #   data <- sales2019
  #   if (input$sel_cust != 'Tout'){
  #     data <- data[data$Clients == input$sel_cust, ]
  #   }
  #   if (input$sel_type != 'Tout'){
  #     data <- data[data$Type.de.client == input$sel_type, ]
  #   }
  #   if (input$sel_zone != 'Tout'){
  #     data <- data[data$Zone.géographique == input$sel_zone, ]
  #   }
  #   if (input$sel_city != 'Tout'){
  #     data <- data[data$Commune == input$sel_city, ]
  #   }
  #   data
  # }))
  #######################################
  
  
  ########################################
  ##### Graphs
  
  output$pricePlot <- renderPlot({
    # Plot
    ggplot(prix2019, aes(x= prix2019[,1])) +
      geom_point(aes(y = prix2019[,2], color = names(prix2019[2])),size = prix2019[,6])+
      geom_point(aes(y = prix2019[,3], color = names(prix2019[3])), size = 4)+
      geom_point(aes(y = prix2019[,4], color = names(prix2019[4])), size = 4)+
      xlab("Trimestres 2019") +
      ylab("Prix")
    
  })
  #######################################
  
  
  ########################################
  ##### Upload des datas
  
  csvOne <- eventReactive(input$csv1,{
    inFile <- input$csv1
    if (is.null(inFile))
      return(NULL)
    
    read.csv(inFile$datapath, sep = ';')
  })
  
  output$csvname1 <- renderText(paste("Tableaux n°1 : ", input$csv1$name))
  
  csvTwo <- eventReactive(input$csv2,{
    inFile <- input$csv2
    if (is.null(inFile))
      return(NULL)
    
    read.csv(inFile$datapath, sep = ';')
  })
  
  output$csvname2 <- renderText(paste("Tableaux n°2 : ", input$csv2$name))
  
  csvThree <- eventReactive(input$csv3,{
    inFile <- input$csv3
    if (is.null(inFile))
      return(NULL)
    
    read.csv(inFile$datapath, sep = ';')
  })
  
  output$csvname3 <- renderText(paste("Tableaux n°3 : ", input$csv3$name))
  
  csvFour <- eventReactive(input$csv4,{
    inFile <- input$csv4
    if (is.null(inFile))
      return(NULL)
    
    read.csv(inFile$datapath, sep = ';')
  })
  
  output$csvname4 <- renderText(paste("Tableaux n°4 : ", input$csv4$name))
  
  #######################################
  
  ########################################
  ##### Fusions des données 
  # do.call permet de faire un merge sur une liste de dataframes
  final_react <- eventReactive(input$fusionBtn,
                               do.call("rbind", list(csvOne(), csvTwo(), csvThree(), csvFour())))
  
  output$final <- DT::renderDataTable({
    final_react()
  })
  
  #######################################
  
  ########################################
  ##### Download management
  
  
  output$downloadBtn <- downloadHandler(
    filename = function() { 
      paste("finalTable.csv", sep=";")
    },
    content = function(file) {
      write.csv(final_react(), file)
    })


  villes <- data.frame(Ville = c("Anglet", "Bayonne", "Biarritz", "Biscarrosse", "Hasparren", "Mios","orthez", "pau", "pessac", "pey", "salles", "souraïde", "tarnos", "urt", "ustaritz", "ychoux"),
                       Latitude = c(43.483333, 43.483333, 43.483333, 44.391667, 43.383333, 44.6, 43.483333, 43.3, 44.8, 43.633333, 44.3300, 43.35, 43.533333, 43.5, 43.4, 44.333333),
                       Longitude = c(-1.533333, -1.483333, -1.566667, -1.166667, -1.3, -0.933333, -0.766667, -0.366667, -0.616667, -1.2, 0.5219, -1.466667, -1.466667, -1.283333, -1.45, -0.966667),
                       CA_2019 = c(14563, 16351, 3285, 2516, 540, 1838, 7969, 279, 0, 0, 1680, 14355, 11166, 289, 5596, 465))
  
  couleurs <- colorNumeric("YlOrRd", villes$CA_2019, n = 5)
  
  output$mymap <- renderLeaflet({
    leaflet(villes) %>% 
      addTiles() %>%
      addCircles(lng = ~Longitude, lat = ~Latitude, weight = 1,
                 radius = ~sqrt(CA_2019) * 30, 
                 popup = ~paste(Ville, ":", CA_2019),
                 color = "#a500a5", fillOpacity = 0.5) %>%
      addLegend(pal = couleurs, values = ~CA_2019, opacity = 0.9)
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)
